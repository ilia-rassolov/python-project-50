from scripts.gendiff import generate_diff

diff = generate_diff('/home/user/PycharmProjects/HexletEx/py-pr-50/files/file1.json',
           '/home/user/PycharmProjects/HexletEx/py-pr-50/files/file2.json')

print(diff)