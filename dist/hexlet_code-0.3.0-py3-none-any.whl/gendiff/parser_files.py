import json

data1 = json.load(open('home/mint/PycharmProjects/python-project-50/tests/fixtures/f1_input.json'))
print('data1 = ', data1)
data2 = json.load(open('python-project-50/tests/fixtures/f2_input.json'))
