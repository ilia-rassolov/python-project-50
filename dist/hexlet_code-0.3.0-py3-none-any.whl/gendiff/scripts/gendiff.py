import argparse
import pathlib
import json


# parser = argparse.ArgumentParser(description='Compares two configuration files and shows a difference.')
# parser.add_argument('first_file', type=pathlib.Path)
# parser.add_argument('second_file', type=pathlib.Path)
# parser.add_argument('-f', '--format', help='set format of output')
#
# args = parser.parse_args()

def generate_diff(first_file, second_file):

    data1 = json.load(open(first_file))
    data2 = json.load(open(second_file))

    # print('data1 = ', data1)
    # print('data2 = ', data2)

    keys = list(set(list(data1.keys()) + list(data2.keys())))  # объединяем ключи через множество в список
    keys.sort()
    # print('keys = ', keys)

    diff_str = open("/home/user/PycharmProjects/HexletEx/py-pr-50/files/diff_file", "w")
    diff_str.write('{\n')
    for key in keys:
        if key in data1:
            if key in data2:
                if data1[key] == data2[key]:
                    diff_str.write(f'    {key}: {data1[key]}\n')
                else:
                    diff_str.write(f'  - {key}: {data1[key]}\n  + {key}: {data2[key]}\n')
            else:
                diff_str.write(f'  - {key}: {data1[key]}\n')
        else:
            diff_str.write(f'  + {key}: {data2[key]}\n')
    diff_str.write('}')
    diff_str.close()
    diff_str = open("/home/user/PycharmProjects/HexletEx/py-pr-50/files/diff_file")
    return diff_str.read()
    # print(diff_str.read())



    # result =
    # return result



    # diff_r = open("/home/user/PycharmProjects/HexletEx/py-pr-50/files/diff_file")
    # for l in diff_r:
    #     print(l)
    # d = diff_r.read()
    # print(diff_str)






# #
# generate_diff('/home/user/PycharmProjects/HexletEx/py-pr-50/files/file1.json',
#            '/home/user/PycharmProjects/HexletEx/py-pr-50/files/file2.json')
