# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.scripts']

package_data = \
{'': ['*'], 'gendiff': ['json_files/*', 'yaml_files/*']}

install_requires = \
['pytest-cov>=4.1.0,<5.0.0', 'pyyaml>=6.0.1,<7.0.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.3.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n\n[![hexlet-check](https://github.com/ilia-rassolov/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/ilia-rassolov/python-project-50/actions/workflows/hexlet-check.yml)\n\n[![my-check](https://github.com/ilia-rassolov/python-project-50/actions/workflows/my-check.yml/badge.svg)](https://github.com/ilia-rassolov/python-project-50/actions/workflows/my-check.yml)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/a723eafeff9ce50f593f/maintainability)](https://codeclimate.com/github/ilia-rassolov/python-project-50/maintainability)\n\n[![Test Coverage](https://api.codeclimate.com/v1/badges/a723eafeff9ce50f593f/test_coverage)](https://codeclimate.com/github/ilia-rassolov/python-project-50/test_coverage)\n\n\nЭто мой второй учебный проект на Hexlet. Он называется **Вычислитель отличий**\n\n1. Команда **gendiff -h** выводит описание решаемой задачи и список опций\n\n   **gendiff gendiff/json_files/file1.json gendiff/json_files/file2.json** \n\n   сравнивает данные, расположенные в аргументах (пути 2-х файлов)\n\n\n[![asciicast](https://asciinema.org/a/OHyPacXfjy2BaJmTb3GngHDX9.svg)](https://asciinema.org/a/OHyPacXfjy2BaJmTb3GngHDX9)\n\n\n\n',
    'author': 'ilia rassolov',
    'author_email': 'iliarassolov@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
