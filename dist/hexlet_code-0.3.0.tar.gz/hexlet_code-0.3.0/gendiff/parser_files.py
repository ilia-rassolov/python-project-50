import json
# from gendiff.parser_args import args


# def
# if args:

data1 = json.load(open('tests/fixtures/f1_input.json'))
data2 = json.load(open('tests/fixtures/f2_input.json'))

# print('data1 = ', data1)
